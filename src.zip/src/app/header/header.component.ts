import { Component, Input } from '@angular/core';

@Component({
  standalone: true,
  selector: 'his-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

 public headerElement:string = `頁首元件 + 樣板 + 樣式`;
 public headerTitleEng:string = `(HeaderComponent)`;
}
