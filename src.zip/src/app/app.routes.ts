import { Routes } from '@angular/router';
import {Page1Component} from './article/page1/page1.component';
import {Page2Component} from './article/page2/page2.component';

export const routes: Routes = [
  {
    path: 'page1/:id',
    component: Page1Component
  },
  {
    path: 'page2/:id',
    component: Page2Component
  },
  {
    path: '**',
    component: Page1Component
  }
];
