import { Component, Input } from '@angular/core';

@Component({
  standalone: true,
  selector: 'his-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component {

  public articleTitle: string = `主要內容`;
  public articleElement: string = `元件 + 樣式 + 樣板`;
  public articleTitleEng: string = `ArticleComponent`;

  @Input() id = '';

}
