import { Component , Input} from '@angular/core';

@Component({
  standalone: true,
  selector: 'his-page2',
  templateUrl: './page2.component.html',
  styleUrls: ['./page2.component.css']
})
export class Page2Component {

  public articleTitle: string = `主要內容`;
  public articleElement: string = `元件 + 樣式 + 樣板`;
  public articleTitleEng: string = `ArticleComponent`;

  @Input() id = '';

}
