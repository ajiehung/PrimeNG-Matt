import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { HeaderComponent } from './header/header.component';
import { AsideComponent } from './aside/aside.component';

@Component({
    standalone: true,
    selector: 'app-root',
    templateUrl: './app.component.html',
    imports: [AsideComponent, HeaderComponent, RouterOutlet],
    styleUrls: [],
})
export class AppComponent {
  public title:string = `demo3`
}
